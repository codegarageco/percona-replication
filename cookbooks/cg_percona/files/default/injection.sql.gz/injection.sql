# Dummy

CREATE DATABASE IF NOT EXISTS `eat_tofu`;

USE `eat_tofu`;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `users` (name, age) VALUES ('test', 10);
